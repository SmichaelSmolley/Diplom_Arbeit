#include <stm32f10x.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdbool.h>
#include "NVIC.h"
//NVIC INIT
void NVIC_init (char position, char priority)
{
	NVIC->IP[position]=(priority<<4); // setzt interrupt priorit�t
	NVIC->ICPR[position/32] |= (0x01<<(position%32)); // verhindert interupt wenn ausgel�st
	NVIC->ISER[position/32] |= (0x01<<(position%32)); // Enable Interrupt
}
